const page = document.documentElement;
const contents = document.querySelector('#contents');
const contentsLink = document.querySelector('.contents-link');
const article = document.querySelector('article');
const application = document.querySelector('[data-application-cta]');
let progressFrame = 0;

function updateProgress() {
  const end = article.getBoundingClientRect().bottom + window.scrollY;
  const distance = Math.max(1, end - window.innerHeight);
  const progress = Math.min(1, Math.max(0, window.scrollY / distance));
  page.style.setProperty('--reading-progress', progress);
  progressFrame = 0;
}

function requestProgressUpdate() {
  if (!progressFrame) progressFrame = window.requestAnimationFrame(updateProgress);
}

window.addEventListener('scroll', requestProgressUpdate, { passive: true });
window.addEventListener('resize', requestProgressUpdate);
window.addEventListener('pageshow', requestProgressUpdate);
new ResizeObserver(requestProgressUpdate).observe(article);

contentsLink.addEventListener('click', () => {
  contents.open = true;
  contents.querySelector('summary').focus({ preventScroll: true });
});

application.addEventListener('click', () => {
  const formStatus = document.querySelector('#form-status');
  if (formStatus) {
    formStatus.textContent = 'Анкета пока не подключена.';
    return;
  }

  window.dispatchEvent(new CustomEvent('application_cta_click', {
    detail: { placement: 'article_end' }
  }));
});
